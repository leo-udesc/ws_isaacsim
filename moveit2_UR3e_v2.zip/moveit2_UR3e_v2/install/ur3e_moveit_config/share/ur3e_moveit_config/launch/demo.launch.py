from moveit_configs_utils import MoveItConfigsBuilder
from moveit_configs_utils.launches import generate_demo_launch


def generate_launch_description():
    moveit_config = MoveItConfigsBuilder("ur3e_egh80", package_name="ur3e_moveit_config").to_moveit_configs()
    return generate_demo_launch(moveit_config)

#from moveit_configs_utils import MoveItConfigsBuilder
#from moveit_configs_utils.launches import generate_demo_launch


#def generate_launch_description():
 #   moveit_config = MoveItConfigsBuilder("ur3e_egh80", package_name="ur3e_moveit_config").to_moveit_configs()

 #   additional_parameters = {
 #       'moveit_simple_controller_manager.arm_controller.action_ns': '/follow_joint_trajectory'
 #   }

 #   return generate_demo_launch(moveit_config, additional_parameters=additional_parameters)
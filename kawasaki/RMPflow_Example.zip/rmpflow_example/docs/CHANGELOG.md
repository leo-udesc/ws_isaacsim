# Changelog

## [0.1.0] - 2023-08-15

### Added

- Initial version of Lula Base Template Extension
